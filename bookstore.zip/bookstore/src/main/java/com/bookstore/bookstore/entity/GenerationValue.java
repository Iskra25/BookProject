package com.bookstore.bookstore.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "generation_value")
public class GenerationValue {
}