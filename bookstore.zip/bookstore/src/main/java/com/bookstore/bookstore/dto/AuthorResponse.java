package com.bookstore.bookstore.dto;

public class AuthorResponse {

}
